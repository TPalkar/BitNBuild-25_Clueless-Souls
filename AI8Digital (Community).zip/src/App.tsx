import { NourishNetLanding } from "./components/NourishNetLanding";

export default function App() {
  return <NourishNetLanding />;
}