import { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Switch } from "../ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { 
  Calendar, CreditCard, Pause, Play, Edit, Check, 
  Clock, Package, DollarSign, AlertCircle 
} from "lucide-react";

interface SubscriptionManagerProps {
  userData: {
    name: string;
    currentPlan: string;
    nextDelivery: string;
    totalOrders: number;
    memberSince: string;
  };
}

export function SubscriptionManager({ userData }: SubscriptionManagerProps) {
  const [isPaused, setIsPaused] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);

  const currentSubscription = {
    plan: "Monthly Premium",
    price: 3200,
    deliveriesPerMonth: 30,
    nextBilling: "Feb 15, 2024",
    status: "active",
    mealsRemaining: 18,
    daysRemaining: 12
  };

  const availablePlans = [
    {
      id: "daily-basic",
      name: "Daily Basic",
      price: 150,
      period: "per day",
      deliveries: 1,
      features: ["Single meal", "Basic menu", "Standard delivery"]
    },
    {
      id: "weekly-standard",
      name: "Weekly Standard",
      price: 800,
      period: "per week",
      deliveries: 7,
      features: ["7 meals/week", "Variety menu", "Priority support"],
      savings: "Save ₹250/week"
    },
    {
      id: "monthly-premium",
      name: "Monthly Premium",
      price: 3200,
      period: "per month",
      deliveries: 30,
      features: ["30 meals/month", "Premium menu", "Free customization", "Priority delivery"],
      savings: "Save ₹1300/month",
      popular: true
    }
  ];

  const recentBilling = [
    { date: "Jan 15, 2024", amount: 3200, plan: "Monthly Premium", status: "paid" },
    { date: "Dec 15, 2023", amount: 3200, plan: "Monthly Premium", status: "paid" },
    { date: "Nov 15, 2023", amount: 800, plan: "Weekly Standard", status: "paid" }
  ];

  return (
    <div className="space-y-4">
      {/* Current Plan Overview */}
      <Card className="dark-card">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-dark-primary">{currentSubscription.plan}</h3>
            <p className="text-dark-cta font-bold text-lg">₹{currentSubscription.price}/month</p>
          </div>
          <Badge className={`${currentSubscription.status === 'active' ? 'bg-green-600' : 'bg-orange-600'} text-white`}>
            {currentSubscription.status}
          </Badge>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="text-center p-3 rounded-lg bg-dark-bg">
            <Package className="w-6 h-6 text-dark-cta mx-auto mb-1" />
            <p className="text-dark-primary font-bold">{currentSubscription.mealsRemaining}</p>
            <p className="text-xs text-dark-secondary">Meals Left</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-dark-bg">
            <Calendar className="w-6 h-6 text-dark-cta mx-auto mb-1" />
            <p className="text-dark-primary font-bold">{currentSubscription.daysRemaining}</p>
            <p className="text-xs text-dark-secondary">Days Left</p>
          </div>
        </div>

        <div className="space-y-2 text-sm text-dark-secondary">
          <div className="flex justify-between">
            <span>Next billing:</span>
            <span>{currentSubscription.nextBilling}</span>
          </div>
          <div className="flex justify-between">
            <span>Monthly deliveries:</span>
            <span>{currentSubscription.deliveriesPerMonth}</span>
          </div>
        </div>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="dark-card p-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-dark-primary font-medium">Pause Plan</p>
              <p className="text-xs text-dark-secondary">Temporarily stop deliveries</p>
            </div>
            <Switch 
              checked={isPaused}
              onCheckedChange={setIsPaused}
            />
          </div>
        </Card>

        <Dialog>
          <DialogTrigger asChild>
            <Card className="dark-card p-3 cursor-pointer hover:bg-dark-hover transition-colors">
              <div className="text-center">
                <Edit className="w-6 h-6 text-dark-cta mx-auto mb-1" />
                <p className="text-dark-primary font-medium">Change Plan</p>
                <p className="text-xs text-dark-secondary">Upgrade or downgrade</p>
              </div>
            </Card>
          </DialogTrigger>
          <DialogContent className="bg-dark-card border-dark-border max-w-sm">
            <DialogHeader>
              <DialogTitle className="text-dark-primary">Choose Your Plan</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              {availablePlans.map((plan) => (
                <Card 
                  key={plan.id} 
                  className={`dark-card cursor-pointer transition-colors ${
                    plan.id === 'monthly-premium' ? 'border-dark-cta' : 'border-dark-border'
                  } hover:bg-dark-hover`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="flex items-center space-x-2">
                        <h4 className="text-dark-primary font-medium">{plan.name}</h4>
                        {plan.popular && (
                          <Badge className="bg-dark-cta text-white text-xs">Popular</Badge>
                        )}
                      </div>
                      <p className="text-dark-cta font-bold">₹{plan.price} {plan.period}</p>
                      {plan.savings && (
                        <p className="text-dark-positive text-xs">{plan.savings}</p>
                      )}
                    </div>
                    {plan.id === 'monthly-premium' && (
                      <Check className="w-5 h-5 text-dark-cta" />
                    )}
                  </div>
                  <div className="space-y-1">
                    {plan.features.map((feature) => (
                      <p key={feature} className="text-xs text-dark-secondary">• {feature}</p>
                    ))}
                  </div>
                </Card>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Billing History */}
      <Card className="dark-card">
        <h4 className="text-dark-primary mb-3">Billing History</h4>
        <div className="space-y-2">
          {recentBilling.map((bill, index) => (
            <div key={index} className="flex items-center justify-between p-2 rounded border border-dark-border">
              <div>
                <p className="text-dark-primary font-medium">₹{bill.amount}</p>
                <p className="text-xs text-dark-secondary">{bill.date}</p>
              </div>
              <div className="text-right">
                <Badge className="bg-green-600 text-white mb-1">
                  {bill.status}
                </Badge>
                <p className="text-xs text-dark-secondary">{bill.plan}</p>
              </div>
            </div>
          ))}
        </div>
        <Button variant="outline" className="w-full mt-3 border-dark-border text-dark-secondary">
          View All Transactions
        </Button>
      </Card>

      {/* Payment Method */}
      <Card className="dark-card">
        <div className="flex justify-between items-center mb-3">
          <h4 className="text-dark-primary">Payment Method</h4>
          <Button variant="ghost" size="sm" className="text-dark-secondary">
            <Edit className="w-3 h-3 mr-1" />
            Change
          </Button>
        </div>
        <div className="flex items-center space-x-3 p-3 rounded border border-dark-border">
          <CreditCard className="w-6 h-6 text-dark-cta" />
          <div>
            <p className="text-dark-primary font-medium">•••• •••• •••• 4532</p>
            <p className="text-xs text-dark-secondary">Expires 12/26</p>
          </div>
        </div>
      </Card>

      {/* Pause Subscription Dialog */}
      {isPaused && (
        <Card className="dark-card bg-orange-600/10 border-orange-600">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-orange-500 mt-0.5" />
            <div className="flex-1">
              <h4 className="text-orange-500 font-medium">Subscription Paused</h4>
              <p className="text-dark-secondary text-sm">Your deliveries are temporarily stopped. You can resume anytime.</p>
              <Button 
                size="sm" 
                className="mt-2 bg-orange-600 hover:bg-orange-700 text-white"
                onClick={() => setIsPaused(false)}
              >
                <Play className="w-3 h-3 mr-1" />
                Resume Deliveries
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}