import { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { 
  MapPin, Truck, Clock, CheckCircle, Phone, Navigation, 
  Star, User, Package 
} from "lucide-react";

export function DeliveryTracking() {
  const [trackingStatus, setTrackingStatus] = useState("out-for-delivery");

  const currentDelivery = {
    orderId: "ORD-001",
    menu: "North Indian Thali",
    estimatedTime: "12:30 PM",
    currentTime: "12:25 PM",
    driver: {
      name: "Ramesh Kumar",
      phone: "+91 98765 43210",
      rating: 4.8,
      vehicle: "KA 01 AB 1234"
    },
    status: "out-for-delivery",
    timeline: [
      { step: "Order Confirmed", time: "11:45 AM", completed: true },
      { step: "Preparing Your Meal", time: "12:00 PM", completed: true },
      { step: "Out for Delivery", time: "12:15 PM", completed: true, current: true },
      { step: "Delivered", time: "12:30 PM", completed: false }
    ]
  };

  const deliverySteps = [
    { 
      icon: CheckCircle, 
      title: "Order Confirmed", 
      description: "Your order has been confirmed and payment processed",
      time: "11:45 AM",
      completed: true 
    },
    { 
      icon: Package, 
      title: "Preparing Your Meal", 
      description: "Our kitchen is preparing your fresh meal",
      time: "12:00 PM",
      completed: true 
    },
    { 
      icon: Truck, 
      title: "Out for Delivery", 
      description: "Your meal is on the way with our delivery partner",
      time: "12:15 PM",
      completed: true,
      current: true 
    },
    { 
      icon: MapPin, 
      title: "Delivered", 
      description: "Your meal has been delivered. Enjoy!",
      time: "12:30 PM",
      completed: false 
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "preparing": return "bg-orange-600";
      case "out-for-delivery": return "bg-blue-600";
      case "delivered": return "bg-green-600";
      default: return "bg-gray-600";
    }
  };

  return (
    <div className="space-y-4">
      {/* Live Tracking Header */}
      <Card className="dark-card">
        <div className="text-center mb-4">
          <h3 className="text-dark-primary">Your Order is On the Way!</h3>
          <p className="text-dark-secondary">Track your delivery in real-time</p>
        </div>
        
        <div className="flex justify-between items-center mb-4">
          <div>
            <p className="text-dark-primary font-medium">{currentDelivery.menu}</p>
            <p className="text-sm text-dark-secondary">Order #{currentDelivery.orderId}</p>
          </div>
          <Badge className={`${getStatusColor(currentDelivery.status)} text-white`}>
            <Truck className="w-3 h-3 mr-1" />
            Out for Delivery
          </Badge>
        </div>

        <div className="bg-dark-bg rounded-lg p-4 mb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-dark-cta" />
              <span className="text-dark-secondary">Estimated Arrival</span>
            </div>
            <span className="text-dark-primary font-bold">{currentDelivery.estimatedTime}</span>
          </div>
          <div className="mt-2 text-center">
            <span className="text-dark-positive">5 minutes away</span>
          </div>
        </div>
      </Card>

      {/* Live Map Visualization */}
      <Card className="dark-card">
        <h4 className="text-dark-primary mb-3">Live Tracking Map</h4>
        <div className="bg-dark-bg rounded-lg border border-dark-border overflow-hidden">
          {/* Map Header */}
          <div className="p-3 border-b border-dark-border bg-dark-card">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                <span className="text-dark-secondary text-sm">Delivery partner is en route</span>
              </div>
              <span className="text-dark-primary text-sm font-medium">ETA: 5 minutes</span>
            </div>
          </div>

          {/* Simplified Route Map */}
          <div className="h-48 relative bg-gradient-to-br from-dark-bg to-dark-hover">
            <div className="absolute inset-0 opacity-20">
              <svg className="w-full h-full" viewBox="0 0 400 200">
                <defs>
                  <pattern id="consumerGrid" width="20" height="20" patternUnits="userSpaceOnUse">
                    <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#374151" strokeWidth="0.5"/>
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#consumerGrid)" />
              </svg>
            </div>

            {/* Route Path */}
            <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 200">
              {/* Delivery Route Line */}
              <path
                d="M 50 100 Q 150 50 250 100 Q 300 120 350 100"
                stroke="#3B82F6"
                strokeWidth="3"
                fill="none"
                strokeDasharray="8,4"
                className="animate-pulse"
              />
              
              {/* Kitchen Location */}
              <circle cx="50" cy="100" r="6" fill="#22C55E" />
              <text x="50" y="85" textAnchor="middle" className="fill-dark-primary text-xs font-medium">
                Kitchen
              </text>
              
              {/* Current Driver Location */}
              <circle cx="250" cy="100" r="8" fill="#3B82F6" className="animate-pulse">
                <animate attributeName="r" values="6;10;6" dur="2s" repeatCount="indefinite"/>
              </circle>
              <text x="250" y="85" textAnchor="middle" className="fill-dark-primary text-xs font-medium">
                Driver
              </text>
              
              {/* Your Location */}
              <circle cx="350" cy="100" r="6" fill="#F59E0B" />
              <text x="350" y="85" textAnchor="middle" className="fill-dark-primary text-xs font-medium">
                You
              </text>
            </svg>

            {/* Driver Info Overlay */}
            <div className="absolute top-3 left-3 bg-dark-card/90 p-2 rounded-lg">
              <div className="flex items-center space-x-2">
                <Truck className="w-3 h-3 text-blue-500" />
                <span className="text-dark-primary text-sm font-medium">{currentDelivery.driver.name}</span>
              </div>
              <p className="text-dark-secondary text-xs">0.8 km away</p>
            </div>

            {/* ETA Indicator */}
            <div className="absolute top-3 right-3 bg-green-600/90 p-2 rounded-lg">
              <div className="flex items-center space-x-1">
                <Clock className="w-3 h-3 text-white" />
                <span className="text-white text-sm font-medium">5 min</span>
              </div>
            </div>
          </div>

          {/* Map Actions */}
          <div className="p-3 border-t border-dark-border bg-dark-card">
            <div className="flex space-x-2">
              <Button size="sm" className="dark-button-primary flex-1">
                <Navigation className="w-3 h-3 mr-1" />
                Open in Maps
              </Button>
              <Button size="sm" variant="outline" className="border-dark-border text-dark-secondary">
                <Phone className="w-3 h-3 mr-1" />
                Call Driver
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* Delivery Partner Info */}
      <Card className="dark-card">
        <h4 className="text-dark-primary mb-3">Your Delivery Partner</h4>
        <div className="flex items-center space-x-3 mb-3">
          <div className="w-12 h-12 bg-dark-cta rounded-full flex items-center justify-center">
            <User className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <p className="text-dark-primary font-medium">{currentDelivery.driver.name}</p>
            <div className="flex items-center space-x-2">
              <Star className="w-3 h-3 text-yellow-500" />
              <span className="text-sm text-dark-secondary">{currentDelivery.driver.rating}</span>
              <span className="text-sm text-dark-secondary">• {currentDelivery.driver.vehicle}</span>
            </div>
          </div>
          <Button size="sm" className="dark-button-secondary">
            <Phone className="w-3 h-3 mr-1" />
            Call
          </Button>
        </div>
      </Card>

      {/* Delivery Timeline */}
      <Card className="dark-card">
        <h4 className="text-dark-primary mb-4">Delivery Progress</h4>
        <div className="space-y-4">
          {deliverySteps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={index} className="flex items-start space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  step.completed 
                    ? 'bg-green-600' 
                    : step.current 
                      ? 'bg-blue-600' 
                      : 'bg-gray-600'
                }`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className={`font-medium ${
                        step.completed || step.current 
                          ? 'text-dark-primary' 
                          : 'text-dark-secondary'
                      }`}>
                        {step.title}
                      </p>
                      <p className="text-sm text-dark-secondary">{step.description}</p>
                    </div>
                    <span className={`text-xs ${
                      step.completed || step.current 
                        ? 'text-dark-primary' 
                        : 'text-dark-secondary'
                    }`}>
                      {step.time}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <Button variant="outline" className="border-dark-border text-dark-secondary">
          <Phone className="w-4 h-4 mr-2" />
          Call Support
        </Button>
        <Button variant="outline" className="border-dark-border text-dark-secondary">
          <MapPin className="w-4 h-4 mr-2" />
          Update Address
        </Button>
      </div>

      {/* Delivery Instructions */}
      <Card className="dark-card">
        <h4 className="text-dark-primary mb-2">Delivery Instructions</h4>
        <p className="text-dark-secondary text-sm mb-3">
          Please ring the doorbell and leave at the door if no answer. Contact me at {currentDelivery.driver.phone} for any issues.
        </p>
        <Button variant="outline" size="sm" className="border-dark-border text-dark-secondary">
          Edit Instructions
        </Button>
      </Card>
    </div>
  );
}