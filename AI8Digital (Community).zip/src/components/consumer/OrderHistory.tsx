import { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../ui/dialog";
import { 
  Search, Filter, Star, Calendar, Package, 
  ThumbsUp, ThumbsDown, MessageCircle, Repeat 
} from "lucide-react";

export function OrderHistory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  const orders = [
    {
      id: "ORD-067",
      date: "2024-02-10",
      menu: "North Indian Thali",
      price: 120,
      status: "delivered",
      rating: 5,
      deliveryTime: "12:25 PM",
      items: ["Roti", "Dal Tadka", "Mixed Vegetable", "Jeera Rice", "Pickle", "Papad"],
      feedback: "Excellent food quality and timely delivery!"
    },
    {
      id: "ORD-066",
      date: "2024-02-09",
      menu: "South Indian Special",
      price: 110,
      status: "delivered",
      rating: 4,
      deliveryTime: "12:30 PM",
      items: ["Steamed Rice", "Sambar", "Rasam", "Poriyal", "Curd", "Pickle"],
      feedback: "Good taste but could be a bit more spicy"
    },
    {
      id: "ORD-065",
      date: "2024-02-08",
      menu: "Gujarati Thali",
      price: 130,
      status: "delivered",
      rating: 5,
      deliveryTime: "12:20 PM",
      items: ["Chapati", "Dal", "Bhaji", "Khichdi", "Kadhi", "Sweet"],
      feedback: "Loved the authentic Gujarati flavors!"
    },
    {
      id: "ORD-064",
      date: "2024-02-07",
      menu: "North Indian Thali",
      price: 120,
      status: "cancelled",
      rating: null,
      deliveryTime: null,
      items: [],
      feedback: "Cancelled due to emergency"
    },
    {
      id: "ORD-063",
      date: "2024-02-06",
      menu: "Bengali Special",
      price: 125,
      status: "delivered",
      rating: 4,
      deliveryTime: "12:35 PM",
      items: ["Rice", "Fish Curry", "Dal", "Vegetable", "Sweet"],
      feedback: "Fish curry was delicious"
    }
  ];

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.menu.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered": return "bg-green-600";
      case "cancelled": return "bg-red-600";
      case "preparing": return "bg-orange-600";
      default: return "bg-gray-600";
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-3 h-3 ${i < rating ? 'text-yellow-500 fill-current' : 'text-gray-400'}`}
      />
    ));
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h3 className="text-dark-primary">Order History</h3>
        <p className="text-dark-secondary">View all your previous orders and provide feedback</p>
      </div>

      {/* Filters */}
      <Card className="dark-card">
        <div className="flex flex-col space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-dark-secondary w-4 h-4" />
            <Input
              placeholder="Search orders..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-dark-bg border-dark-border text-dark-primary"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="bg-dark-bg border-dark-border text-dark-primary">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent className="bg-dark-card border-dark-border">
              <SelectItem value="all">All Orders</SelectItem>
              <SelectItem value="delivered">Delivered</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
              <SelectItem value="preparing">Preparing</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Order List */}
      <div className="space-y-3">
        {filteredOrders.map((order) => (
          <Card key={order.id} className="dark-card">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h4 className="text-dark-primary font-medium">{order.menu}</h4>
                <p className="text-sm text-dark-secondary">Order #{order.id}</p>
                <p className="text-sm text-dark-secondary">{order.date}</p>
              </div>
              <div className="text-right">
                <Badge className={`${getStatusColor(order.status)} text-white mb-1`}>
                  {order.status}
                </Badge>
                <p className="text-dark-cta font-bold">₹{order.price}</p>
              </div>
            </div>

            {order.status === "delivered" && (
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-dark-secondary">Your rating:</span>
                  <div className="flex space-x-1">
                    {renderStars(order.rating || 0)}
                  </div>
                </div>
                <p className="text-sm text-dark-secondary">Delivered at {order.deliveryTime}</p>
              </div>
            )}

            <div className="flex space-x-2">
              <Dialog>
                <DialogTrigger asChild>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="border-dark-border text-dark-secondary flex-1"
                    onClick={() => setSelectedOrder(order)}
                  >
                    View Details
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-dark-card border-dark-border max-w-sm">
                  {selectedOrder && (
                    <>
                      <DialogHeader>
                        <DialogTitle className="text-dark-primary">Order Details</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-dark-primary font-medium mb-2">{selectedOrder.menu}</h4>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <span className="text-dark-secondary">Order ID:</span>
                            <span className="text-dark-primary">{selectedOrder.id}</span>
                            <span className="text-dark-secondary">Date:</span>
                            <span className="text-dark-primary">{selectedOrder.date}</span>
                            <span className="text-dark-secondary">Status:</span>
                            <Badge className={`${getStatusColor(selectedOrder.status)} text-white w-fit`}>
                              {selectedOrder.status}
                            </Badge>
                            <span className="text-dark-secondary">Price:</span>
                            <span className="text-dark-primary">₹{selectedOrder.price}</span>
                          </div>
                        </div>

                        {selectedOrder.items.length > 0 && (
                          <div>
                            <h5 className="text-dark-primary font-medium mb-2">Items Included:</h5>
                            <div className="flex flex-wrap gap-1">
                              {selectedOrder.items.map((item: string) => (
                                <Badge key={item} variant="secondary" className="bg-dark-tag text-white text-xs">
                                  {item}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}

                        {selectedOrder.rating && (
                          <div>
                            <h5 className="text-dark-primary font-medium mb-2">Your Rating & Feedback:</h5>
                            <div className="flex space-x-1 mb-2">
                              {renderStars(selectedOrder.rating)}
                            </div>
                            <p className="text-sm text-dark-secondary">{selectedOrder.feedback}</p>
                          </div>
                        )}
                      </div>
                    </>
                  )}
                </DialogContent>
              </Dialog>

              {order.status === "delivered" && (
                <Button size="sm" className="dark-button-primary">
                  <Repeat className="w-3 h-3 mr-1" />
                  Reorder
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>

      {filteredOrders.length === 0 && (
        <Card className="dark-card text-center py-8">
          <Package className="w-12 h-12 text-dark-secondary mx-auto mb-4" />
          <h4 className="text-dark-primary mb-2">No orders found</h4>
          <p className="text-dark-secondary">Try adjusting your search or filter criteria</p>
        </Card>
      )}

      {/* Order Statistics */}
      <Card className="dark-card">
        <h4 className="text-dark-primary mb-3">Order Statistics</h4>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 rounded-lg bg-dark-bg">
            <p className="text-2xl font-bold text-dark-primary">{orders.filter(o => o.status === 'delivered').length}</p>
            <p className="text-sm text-dark-secondary">Delivered Orders</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-dark-bg">
            <p className="text-2xl font-bold text-dark-primary">
              {(orders.filter(o => o.rating).reduce((sum, o) => sum + (o.rating || 0), 0) / orders.filter(o => o.rating).length).toFixed(1)}
            </p>
            <p className="text-sm text-dark-secondary">Avg Rating Given</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-dark-bg">
            <p className="text-2xl font-bold text-dark-primary">
              ₹{orders.filter(o => o.status === 'delivered').reduce((sum, o) => sum + o.price, 0)}
            </p>
            <p className="text-sm text-dark-secondary">Total Spent</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-dark-bg">
            <p className="text-2xl font-bold text-dark-primary">
              {Math.round((orders.filter(o => o.status === 'delivered').length / orders.length) * 100)}%
            </p>
            <p className="text-sm text-dark-secondary">Success Rate</p>
          </div>
        </div>
      </Card>
    </div>
  );
}