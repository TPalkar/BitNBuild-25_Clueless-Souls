import { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Switch } from "../ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "../ui/dialog";
import { Textarea } from "../ui/textarea";
import { 
  Heart, Star, ChefHat, Leaf, Flame, Droplets, 
  Plus, X, Edit, Save 
} from "lucide-react";

export function MealPreferences() {
  const [preferences, setPreferences] = useState({
    dietary: ["Vegetarian", "No Garlic"],
    spiceLevel: "medium",
    allergies: ["Nuts"],
    favorites: ["Dal Tadka", "Jeera Rice", "Roti"],
    dislikes: ["Bitter Gourd"],
    specialInstructions: "Please avoid using onion in preparations"
  });

  const dietaryOptions = [
    { id: "vegetarian", label: "Vegetarian", icon: Leaf, color: "bg-green-600" },
    { id: "non-vegetarian", label: "Non-Vegetarian", icon: ChefHat, color: "bg-red-600" },
    { id: "vegan", label: "Vegan", icon: Leaf, color: "bg-green-700" },
    { id: "jain", label: "Jain Food", icon: Leaf, color: "bg-orange-600" },
    { id: "no-garlic", label: "No Garlic", icon: Droplets, color: "bg-purple-600" },
    { id: "no-onion", label: "No Onion", icon: Droplets, color: "bg-blue-600" },
    { id: "low-salt", label: "Low Salt", icon: Droplets, color: "bg-gray-600" },
    { id: "low-oil", label: "Low Oil", icon: Droplets, color: "bg-yellow-600" }
  ];

  const spiceLevels = [
    { id: "mild", label: "Mild", icon: "🌶️", color: "bg-green-600" },
    { id: "medium", label: "Medium", icon: "🌶️🌶️", color: "bg-orange-600" },
    { id: "hot", label: "Hot", icon: "🌶️🌶️🌶️", color: "bg-red-600" }
  ];

  const popularItems = [
    "Dal Tadka", "Jeera Rice", "Roti", "Mixed Vegetable", "Curd", 
    "Pickle", "Papad", "Sambar", "Rasam", "Chapati", "Sabzi", "Sweet"
  ];

  const toggleDietaryPreference = (preference: string) => {
    setPreferences(prev => ({
      ...prev,
      dietary: prev.dietary.includes(preference)
        ? prev.dietary.filter(p => p !== preference)
        : [...prev.dietary, preference]
    }));
  };

  const toggleFavorite = (item: string) => {
    setPreferences(prev => ({
      ...prev,
      favorites: prev.favorites.includes(item)
        ? prev.favorites.filter(f => f !== item)
        : [...prev.favorites, item]
    }));
  };

  const removeDietaryPreference = (preference: string) => {
    setPreferences(prev => ({
      ...prev,
      dietary: prev.dietary.filter(p => p !== preference)
    }));
  };

  const removeDislike = (item: string) => {
    setPreferences(prev => ({
      ...prev,
      dislikes: prev.dislikes.filter(d => d !== item)
    }));
  };

  return (
    <div className="space-y-4">
      {/* Dietary Preferences */}
      <Card className="dark-card">
        <div className="flex justify-between items-center mb-3">
          <h4 className="text-dark-primary">Dietary Preferences</h4>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" variant="outline" className="border-dark-border text-dark-secondary">
                <Edit className="w-3 h-3 mr-1" />
                Edit
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-dark-card border-dark-border max-w-sm">
              <DialogHeader>
                <DialogTitle className="text-dark-primary">Select Dietary Preferences</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-2">
                {dietaryOptions.map((option) => {
                  const Icon = option.icon;
                  const isSelected = preferences.dietary.some(p => 
                    p.toLowerCase().replace(' ', '-') === option.id
                  );
                  return (
                    <Button
                      key={option.id}
                      variant={isSelected ? "default" : "outline"}
                      size="sm"
                      className={`${isSelected ? option.color : 'border-dark-border'} text-white`}
                      onClick={() => toggleDietaryPreference(option.label)}
                    >
                      <Icon className="w-3 h-3 mr-1" />
                      {option.label}
                    </Button>
                  );
                })}
              </div>
            </DialogContent>
          </Dialog>
        </div>
        <div className="flex flex-wrap gap-2">
          {preferences.dietary.map((pref) => (
            <Badge key={pref} className="bg-green-600 text-white">
              <Leaf className="w-3 h-3 mr-1" />
              {pref}
              <X 
                className="w-3 h-3 ml-1 cursor-pointer" 
                onClick={() => removeDietaryPreference(pref)}
              />
            </Badge>
          ))}
          {preferences.dietary.length === 0 && (
            <p className="text-dark-secondary text-sm">No dietary restrictions selected</p>
          )}
        </div>
      </Card>

      {/* Spice Level */}
      <Card className="dark-card">
        <h4 className="text-dark-primary mb-3">Spice Level</h4>
        <div className="grid grid-cols-3 gap-2">
          {spiceLevels.map((level) => (
            <Button
              key={level.id}
              variant={preferences.spiceLevel === level.id ? "default" : "outline"}
              className={`${preferences.spiceLevel === level.id ? level.color : 'border-dark-border'} text-white`}
              onClick={() => setPreferences(prev => ({ ...prev, spiceLevel: level.id }))}
            >
              <span className="mr-1">{level.icon}</span>
              {level.label}
            </Button>
          ))}
        </div>
      </Card>

      {/* Favorites */}
      <Card className="dark-card">
        <div className="flex justify-between items-center mb-3">
          <h4 className="text-dark-primary">Favorite Items</h4>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" variant="outline" className="border-dark-border text-dark-secondary">
                <Plus className="w-3 h-3 mr-1" />
                Add
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-dark-card border-dark-border max-w-sm">
              <DialogHeader>
                <DialogTitle className="text-dark-primary">Select Favorite Items</DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto">
                {popularItems.map((item) => (
                  <Button
                    key={item}
                    variant={preferences.favorites.includes(item) ? "default" : "outline"}
                    size="sm"
                    className={`${preferences.favorites.includes(item) ? 'bg-pink-600' : 'border-dark-border'} text-white`}
                    onClick={() => toggleFavorite(item)}
                  >
                    <Heart className="w-3 h-3 mr-1" />
                    {item}
                  </Button>
                ))}
              </div>
            </DialogContent>
          </Dialog>
        </div>
        <div className="flex flex-wrap gap-2">
          {preferences.favorites.map((favorite) => (
            <Badge key={favorite} className="bg-pink-600 text-white">
              <Heart className="w-3 h-3 mr-1" />
              {favorite}
            </Badge>
          ))}
        </div>
      </Card>

      {/* Allergies */}
      <Card className="dark-card">
        <h4 className="text-dark-primary mb-3">Allergies & Restrictions</h4>
        <div className="flex flex-wrap gap-2 mb-3">
          {preferences.allergies.map((allergy) => (
            <Badge key={allergy} className="bg-red-600 text-white">
              {allergy}
              <X 
                className="w-3 h-3 ml-1 cursor-pointer" 
                onClick={() => setPreferences(prev => ({
                  ...prev,
                  allergies: prev.allergies.filter(a => a !== allergy)
                }))}
              />
            </Badge>
          ))}
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button size="sm" variant="outline" className="border-dark-border text-dark-secondary">
              <Plus className="w-3 h-3 mr-1" />
              Add Allergy
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-dark-card border-dark-border max-w-sm">
            <DialogHeader>
              <DialogTitle className="text-dark-primary">Add Allergy Information</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                {["Nuts", "Dairy", "Eggs", "Soy", "Gluten", "Shellfish"].map((allergy) => (
                  <Button
                    key={allergy}
                    variant="outline"
                    size="sm"
                    className="border-dark-border text-dark-secondary"
                    onClick={() => setPreferences(prev => ({
                      ...prev,
                      allergies: [...prev.allergies, allergy]
                    }))}
                  >
                    {allergy}
                  </Button>
                ))}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </Card>

      {/* Dislikes */}
      <Card className="dark-card">
        <h4 className="text-dark-primary mb-3">Items You Dislike</h4>
        <div className="flex flex-wrap gap-2 mb-3">
          {preferences.dislikes.map((dislike) => (
            <Badge key={dislike} className="bg-orange-600 text-white">
              {dislike}
              <X 
                className="w-3 h-3 ml-1 cursor-pointer" 
                onClick={() => removeDislike(dislike)}
              />
            </Badge>
          ))}
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button size="sm" variant="outline" className="border-dark-border text-dark-secondary">
              <Plus className="w-3 h-3 mr-1" />
              Add Item
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-dark-card border-dark-border max-w-sm">
            <DialogHeader>
              <DialogTitle className="text-dark-primary">Items to Avoid</DialogTitle>
            </DialogHeader>
            <div className="grid grid-cols-2 gap-2">
              {["Bitter Gourd", "Okra", "Eggplant", "Cauliflower", "Cabbage", "Mushroom"].map((item) => (
                <Button
                  key={item}
                  variant="outline"
                  size="sm"
                  className="border-dark-border text-dark-secondary"
                  onClick={() => setPreferences(prev => ({
                    ...prev,
                    dislikes: [...prev.dislikes, item]
                  }))}
                >
                  {item}
                </Button>
              ))}
            </div>
          </DialogContent>
        </Dialog>
      </Card>

      {/* Special Instructions */}
      <Card className="dark-card">
        <h4 className="text-dark-primary mb-3">Special Instructions</h4>
        <Textarea
          value={preferences.specialInstructions}
          onChange={(e) => setPreferences(prev => ({ ...prev, specialInstructions: e.target.value }))}
          placeholder="Any special cooking instructions or dietary notes..."
          className="bg-dark-bg border-dark-border text-dark-primary mb-3"
        />
        <Button size="sm" className="dark-button-primary">
          <Save className="w-3 h-3 mr-1" />
          Save Instructions
        </Button>
      </Card>

      {/* Save All Changes */}
      <Button className="dark-button-primary w-full">
        <Save className="w-4 h-4 mr-2" />
        Save All Preferences
      </Button>

      {/* Preference Summary */}
      <Card className="dark-card bg-blue-600/10 border-blue-600">
        <h4 className="text-blue-400 mb-2">Preference Summary</h4>
        <div className="space-y-1 text-sm text-dark-secondary">
          <p>• Dietary: {preferences.dietary.join(", ") || "None specified"}</p>
          <p>• Spice Level: {preferences.spiceLevel.charAt(0).toUpperCase() + preferences.spiceLevel.slice(1)}</p>
          <p>• Favorites: {preferences.favorites.length} items</p>
          <p>• Allergies: {preferences.allergies.join(", ") || "None"}</p>
        </div>
      </Card>
    </div>
  );
}