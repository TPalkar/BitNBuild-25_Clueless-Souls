import { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { 
  ArrowLeft, Bell, MapPin, Clock, User, CreditCard, 
  Calendar, Star, Package, Settings, Heart, Share2 
} from "lucide-react";
import { SubscriptionManager } from "./SubscriptionManager";
import { DeliveryTracking } from "./DeliveryTracking";
import { MealPreferences } from "./MealPreferences";
import { OrderHistory } from "./OrderHistory";

interface ConsumerAppProps {
  onBack: () => void;
}

export function ConsumerApp({ onBack }: ConsumerAppProps) {
  const [activeTab, setActiveTab] = useState("dashboard");

  // Mock user data
  const userData = {
    name: "Rajesh Kumar",
    email: "rajesh.kumar@email.com",
    phone: "+91 98765 43210",
    address: "123 Koramangala, Bangalore",
    currentPlan: "Monthly Premium",
    nextDelivery: "Today, 12:30 PM",
    totalOrders: 67,
    memberSince: "Jan 2024",
    rating: 4.8
  };

  const todaysMenu = {
    name: "North Indian Thali",
    description: "Roti, Dal Tadka, Mixed Vegetable, Jeera Rice, Pickle, Papad",
    price: 120,
    rating: 4.7,
    nutrition: { calories: 450, protein: 15, carbs: 65, fat: 12 },
    eta: "12:30 PM"
  };

  const upcomingDeliveries = [
    { date: "Today", menu: "North Indian Thali", time: "12:30 PM", status: "preparing" },
    { date: "Tomorrow", menu: "South Indian Special", time: "12:30 PM", status: "scheduled" },
    { date: "Day After", menu: "Gujarati Thali", time: "12:30 PM", status: "scheduled" }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "preparing": return "bg-orange-600";
      case "out-for-delivery": return "bg-blue-600";
      case "delivered": return "bg-green-600";
      case "scheduled": return "bg-gray-600";
      default: return "bg-gray-600";
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg">
      {/* Mobile Header */}
      <div className="border-b border-dark-border bg-dark-card">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button
              onClick={onBack}
              variant="ghost"
              size="sm"
              className="text-dark-secondary hover:text-dark-primary"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-dark-cta rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">N</span>
              </div>
              <span className="text-dark-primary font-bold">NourishNet</span>
            </div>
            <Button variant="ghost" size="sm" className="text-dark-secondary">
              <Bell className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          {/* Mobile Tab Navigation */}
          <div className="border-b border-dark-border bg-dark-card">
            <TabsList className="grid w-full grid-cols-5 bg-transparent">
              <TabsTrigger value="dashboard" className="flex flex-col items-center p-2">
                <Package className="w-4 h-4 mb-1" />
                <span className="text-xs">Home</span>
              </TabsTrigger>
              <TabsTrigger value="subscription" className="flex flex-col items-center p-2">
                <Calendar className="w-4 h-4 mb-1" />
                <span className="text-xs">Plan</span>
              </TabsTrigger>
              <TabsTrigger value="tracking" className="flex flex-col items-center p-2">
                <MapPin className="w-4 h-4 mb-1" />
                <span className="text-xs">Track</span>
              </TabsTrigger>
              <TabsTrigger value="preferences" className="flex flex-col items-center p-2">
                <Heart className="w-4 h-4 mb-1" />
                <span className="text-xs">Meals</span>
              </TabsTrigger>
              <TabsTrigger value="profile" className="flex flex-col items-center p-2">
                <User className="w-4 h-4 mb-1" />
                <span className="text-xs">Profile</span>
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="p-4">
            <TabsContent value="dashboard" className="space-y-4 mt-0">
              {/* Welcome Header */}
              <div className="text-center py-4">
                <h2 className="text-dark-primary">Welcome back, {userData.name.split(' ')[0]}!</h2>
                <p className="text-dark-secondary">Your delicious meal is on the way</p>
              </div>

              {/* Today's Menu */}
              <Card className="dark-card">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="text-dark-primary">{todaysMenu.name}</h3>
                    <div className="flex items-center space-x-2 mt-1">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span className="text-sm text-dark-secondary">{todaysMenu.rating}</span>
                      <Badge className="bg-orange-600 text-white">
                        <Clock className="w-3 h-3 mr-1" />
                        {todaysMenu.eta}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-dark-cta font-bold">₹{todaysMenu.price}</p>
                    <p className="text-xs text-dark-secondary">{todaysMenu.nutrition.calories} cal</p>
                  </div>
                </div>
                <p className="text-dark-secondary text-sm mb-3">{todaysMenu.description}</p>
                <div className="flex space-x-2">
                  <Button className="dark-button-primary flex-1">
                    <MapPin className="w-4 h-4 mr-2" />
                    Track Delivery
                  </Button>
                  <Button variant="outline" className="border-dark-border text-dark-secondary">
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </Card>

              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-3">
                <Card className="dark-card text-center">
                  <Package className="w-6 h-6 text-dark-cta mx-auto mb-2" />
                  <p className="text-dark-primary font-bold">{userData.totalOrders}</p>
                  <p className="text-xs text-dark-secondary">Total Orders</p>
                </Card>
                <Card className="dark-card text-center">
                  <Star className="w-6 h-6 text-yellow-500 mx-auto mb-2" />
                  <p className="text-dark-primary font-bold">{userData.rating}</p>
                  <p className="text-xs text-dark-secondary">Your Rating</p>
                </Card>
                <Card className="dark-card text-center">
                  <Calendar className="w-6 h-6 text-dark-cta mx-auto mb-2" />
                  <p className="text-dark-primary font-bold">{userData.memberSince}</p>
                  <p className="text-xs text-dark-secondary">Member Since</p>
                </Card>
              </div>

              {/* Upcoming Deliveries */}
              <Card className="dark-card">
                <h4 className="text-dark-primary mb-3">Upcoming Deliveries</h4>
                <div className="space-y-3">
                  {upcomingDeliveries.map((delivery, index) => (
                    <div key={index} className="flex items-center justify-between p-2 rounded border border-dark-border">
                      <div>
                        <p className="text-dark-primary font-medium">{delivery.date}</p>
                        <p className="text-sm text-dark-secondary">{delivery.menu}</p>
                      </div>
                      <div className="text-right">
                        <Badge className={`${getStatusColor(delivery.status)} text-white mb-1`}>
                          {delivery.status}
                        </Badge>
                        <p className="text-xs text-dark-secondary">{delivery.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Quick Actions */}
              <div className="grid grid-cols-2 gap-3">
                <Button 
                  variant="outline" 
                  className="border-dark-border text-dark-secondary h-16 flex flex-col"
                  onClick={() => setActiveTab("preferences")}
                >
                  <Heart className="w-5 h-5 mb-1" />
                  <span className="text-xs">Meal Preferences</span>
                </Button>
                <Button 
                  variant="outline" 
                  className="border-dark-border text-dark-secondary h-16 flex flex-col"
                  onClick={() => setActiveTab("subscription")}
                >
                  <Settings className="w-5 h-5 mb-1" />
                  <span className="text-xs">Manage Plan</span>
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="subscription" className="mt-0">
              <SubscriptionManager userData={userData} />
            </TabsContent>

            <TabsContent value="tracking" className="mt-0">
              <DeliveryTracking />
            </TabsContent>

            <TabsContent value="preferences" className="mt-0">
              <MealPreferences />
            </TabsContent>

            <TabsContent value="profile" className="mt-0">
              <div className="space-y-4">
                {/* Profile Header */}
                <Card className="dark-card text-center">
                  <div className="w-20 h-20 bg-dark-cta rounded-full flex items-center justify-center mx-auto mb-4">
                    <User className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-dark-primary">{userData.name}</h3>
                  <p className="text-dark-secondary">{userData.currentPlan}</p>
                  <div className="flex justify-center items-center space-x-2 mt-2">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span className="text-dark-secondary">{userData.rating} Rating</span>
                  </div>
                </Card>

                {/* Profile Details */}
                <Card className="dark-card">
                  <h4 className="text-dark-primary mb-3">Contact Information</h4>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <User className="w-4 h-4 text-dark-secondary" />
                      <span className="text-dark-secondary">{userData.email}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <User className="w-4 h-4 text-dark-secondary" />
                      <span className="text-dark-secondary">{userData.phone}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <MapPin className="w-4 h-4 text-dark-secondary" />
                      <span className="text-dark-secondary">{userData.address}</span>
                    </div>
                  </div>
                </Card>

                {/* Account Actions */}
                <div className="space-y-3">
                  <Button 
                    variant="outline" 
                    className="w-full border-dark-border text-dark-secondary"
                    onClick={() => setActiveTab("subscription")}
                  >
                    <Calendar className="w-4 h-4 mr-2" />
                    Order History
                  </Button>
                  <Button variant="outline" className="w-full border-dark-border text-dark-secondary">
                    <CreditCard className="w-4 h-4 mr-2" />
                    Payment Methods
                  </Button>
                  <Button variant="outline" className="w-full border-dark-border text-dark-secondary">
                    <Settings className="w-4 h-4 mr-2" />
                    Settings
                  </Button>
                  <Button variant="outline" className="w-full border-dark-border text-dark-secondary">
                    <Bell className="w-4 h-4 mr-2" />
                    Notifications
                  </Button>
                </div>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
}