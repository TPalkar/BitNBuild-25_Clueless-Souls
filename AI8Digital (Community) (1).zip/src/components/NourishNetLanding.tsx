import { useState } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { 
  ChefHat, Truck, MapPin, Users, BarChart3, Clock, 
  Star, ArrowRight, Play, CheckCircle, Smartphone, 
  Monitor, Zap, Shield, Globe, Heart 
} from "lucide-react";
import { NourishNetApp } from "./NourishNetApp";
import { ImageWithFallback } from './figma/ImageWithFallback';

export function NourishNetLanding() {
  const [showApp, setShowApp] = useState(false);

  if (showApp) {
    return <NourishNetApp />;
  }

  return (
    <div className="min-h-screen bg-cream-ivory-light indian-theme">
      {/* Navigation Header */}
      <nav className="bg-white/80 backdrop-blur-sm border-b border-chai-brown/10 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-spice-gradient rounded-lg flex items-center justify-center">
                <ChefHat className="w-6 h-6 text-white" />
              </div>
              <span className="merriweather text-xl font-bold text-chai-brown">NourishNet</span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-chai-brown hover:text-chai-brown-light transition-colors">Features</a>
              <a href="#vendors" className="text-chai-brown hover:text-chai-brown-light transition-colors">For Vendors</a>
              <a href="#customers" className="text-chai-brown hover:text-chai-brown-light transition-colors">For Customers</a>
              <a href="#pricing" className="text-chai-brown hover:text-chai-brown-light transition-colors">Pricing</a>
            </div>
            <Button 
              className="turmeric-button"
              onClick={() => setShowApp(true)}
            >
              Get Started
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="indian-hero-gradient paisley-pattern py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge className="bg-turmeric-yellow/20 text-chai-brown border-turmeric-yellow/30">
                  🚀 Launching in Mumbai & Bangalore
                </Badge>
                <h1 className="merriweather text-5xl lg:text-6xl font-bold text-chai-brown leading-tight">
                  Digitize Your Tiffin Service with{' '}
                  <span className="text-turmeric-yellow">NourishNet</span>
                </h1>
                <p className="text-xl text-chai-brown/80 leading-relaxed">
                  AI-powered logistics & real-time delivery tracking for India's beloved dabba culture. 
                  Transform your traditional tiffin business into a modern digital powerhouse.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  className="turmeric-button text-lg px-8 py-4"
                  onClick={() => setShowApp(true)}
                >
                  <ChefHat className="w-5 h-5 mr-2" />
                  Start Free Trial
                </Button>
                <Button className="chai-button text-lg px-8 py-4">
                  <Play className="w-5 h-5 mr-2" />
                  Watch Demo
                </Button>
              </div>

              <div className="flex items-center space-x-8 pt-4">
                <div className="flex items-center space-x-1">
                  <Star className="w-5 h-5 text-saffron-gold fill-current" />
                  <span className="text-chai-brown font-medium">4.9/5 Rating</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Users className="w-5 h-5 text-curry-green" />
                  <span className="text-chai-brown font-medium">500+ Vendors</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Globe className="w-5 h-5 text-masala-red" />
                  <span className="text-chai-brown font-medium">15+ Cities</span>
                </div>
              </div>
            </div>

            <div className="relative">
              {/* Main Dabba Image */}
              <div className="relative z-10">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1660987669199-cdee867ab77b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB0aWZmaW4lMjBkYWJiYSUyMGx1bmNoYm94JTIwc3RlZWx8ZW58MXx8fHwxNzU4OTc0NDI0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Traditional Indian Tiffin Dabba"
                  className="w-full h-96 object-cover rounded-2xl shadow-2xl"
                />
                
                {/* Animated Steam Effect */}
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="flex space-x-1">
                    {[...Array(3)].map((_, i) => (
                      <div
                        key={i}
                        className="w-1 h-8 bg-cream-ivory rounded-full opacity-60 animate-pulse"
                        style={{ animationDelay: `${i * 0.5}s` }}
                      ></div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Floating Elements */}
              <div className="absolute -top-8 -right-8 w-24 h-24 bg-turmeric-yellow/20 rounded-full flex items-center justify-center animate-bounce">
                <Truck className="w-10 h-10 text-turmeric-yellow" />
              </div>
              
              <div className="absolute -bottom-8 -left-8 w-20 h-20 bg-masala-red/20 rounded-full flex items-center justify-center animate-pulse">
                <MapPin className="w-8 h-8 text-masala-red" />
              </div>

              {/* Background Pattern */}
              <div className="absolute inset-0 -z-10 dabba-pattern opacity-30"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Rangoli Divider */}
      <div className="rangoli-divider"></div>

      {/* How It Works Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="merriweather text-4xl font-bold text-chai-brown mb-4">
              How NourishNet Works
            </h2>
            <p className="text-xl text-chai-brown/70 max-w-3xl mx-auto">
              Three simple steps to transform your traditional tiffin business into a modern digital operation
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Monitor className="w-12 h-12 text-turmeric-yellow" />,
                title: "Vendor Dashboard",
                description: "Comprehensive management suite for subscribers, menus, and delivery routes with AI-powered optimization",
                color: "bg-turmeric-yellow/10 border-turmeric-yellow/20"
              },
              {
                icon: <Zap className="w-12 h-12 text-masala-red" />,
                title: "Route Optimization",
                description: "AI algorithms analyze traffic patterns and delivery windows to create the most efficient routes",
                color: "bg-masala-red/10 border-masala-red/20"
              },
              {
                icon: <Smartphone className="w-12 h-12 text-curry-green" />,
                title: "Real-time Tracking",
                description: "Live GPS tracking with customer notifications and estimated delivery times",
                color: "bg-curry-green/10 border-curry-green/20"
              }
            ].map((step, index) => (
              <Card key={index} className={`indian-card ${step.color} text-center relative overflow-hidden`}>
                <div className="absolute top-4 right-4 w-8 h-8 bg-chai-brown text-white rounded-full flex items-center justify-center text-sm font-bold">
                  {index + 1}
                </div>
                <div className="flex justify-center mb-6">
                  {step.icon}
                </div>
                <h3 className="merriweather text-xl font-bold text-chai-brown mb-4">
                  {step.title}
                </h3>
                <p className="text-chai-brown/70 leading-relaxed">
                  {step.description}
                </p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* For Vendors Section */}
      <section id="vendors" className="py-20 bg-cream-ivory">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div>
                <Badge className="bg-chai-brown text-white mb-4">For Tiffin Vendors</Badge>
                <h2 className="merriweather text-4xl font-bold text-chai-brown mb-6">
                  Streamline Your Dabba Business Operations
                </h2>
                <p className="text-xl text-chai-brown/80 leading-relaxed mb-8">
                  From subscriber management to route optimization, NourishNet provides everything you need to run a modern tiffin service.
                </p>
              </div>

              <div className="space-y-6">
                {[
                  {
                    icon: <Users className="w-6 h-6 text-turmeric-yellow" />,
                    title: "Subscriber Management",
                    description: "Track customer preferences, dietary restrictions, and subscription plans"
                  },
                  {
                    icon: <BarChart3 className="w-6 h-6 text-masala-red" />,
                    title: "Menu Planning",
                    description: "Dynamic menu creation with seasonal ingredients and nutritional tracking"
                  },
                  {
                    icon: <MapPin className="w-6 h-6 text-curry-green" />,
                    title: "Route Optimization",
                    description: "AI-powered delivery route planning to save time and fuel costs"
                  },
                  {
                    icon: <BarChart3 className="w-6 h-6 text-saffron-gold" />,
                    title: "Business Analytics",
                    description: "Detailed insights on revenue, customer satisfaction, and operational efficiency"
                  }
                ].map((feature, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-white rounded-lg flex items-center justify-center shadow-md">
                      {feature.icon}
                    </div>
                    <div>
                      <h4 className="font-semibold text-chai-brown mb-2">{feature.title}</h4>
                      <p className="text-chai-brown/70">{feature.description}</p>
                    </div>
                  </div>
                ))}
              </div>

              <Button 
                className="turmeric-button"
                onClick={() => setShowApp(true)}
              >
                Explore Vendor Dashboard
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>

            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1559200206-dbfa7a75dd70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdW1iYWklMjBkYWJiYXdhbGElMjBkZWxpdmVyeXxlbnwxfHx8fDE3NTg5NzQ0MjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Mumbai Dabbawala Delivery Service"
                className="w-full h-96 object-cover rounded-2xl shadow-2xl"
              />
              
              {/* Dashboard Preview Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-chai-brown/20 to-transparent rounded-2xl"></div>
              
              {/* Floating Dashboard Elements */}
              <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm p-3 rounded-lg shadow-lg">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-curry-green rounded-full"></div>
                  <span className="text-sm font-medium text-chai-brown">125 Active Orders</span>
                </div>
              </div>
              
              <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm p-3 rounded-lg shadow-lg">
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-turmeric-yellow" />
                  <span className="text-sm font-medium text-chai-brown">Avg: 22 min delivery</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* For Customers Section */}
      <section id="customers" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative order-2 lg:order-1">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1758411898049-4de9588be514?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBkYXNoYm9hcmQlMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzU4OTMyMDAxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Mobile App Interface"
                className="w-full h-96 object-cover rounded-2xl shadow-2xl"
              />
              
              {/* Mobile App UI Overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-turmeric-yellow/10 to-masala-red/10 rounded-2xl"></div>
              
              {/* Floating App Features */}
              <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm p-3 rounded-lg shadow-lg">
                <div className="flex items-center space-x-2">
                  <Heart className="w-4 h-4 text-masala-red" />
                  <span className="text-sm font-medium text-chai-brown">Favorite Meals</span>
                </div>
              </div>
              
              <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm p-3 rounded-lg shadow-lg">
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-curry-green" />
                  <span className="text-sm font-medium text-chai-brown">Live Tracking</span>
                </div>
              </div>
            </div>

            <div className="space-y-8 order-1 lg:order-2">
              <div>
                <Badge className="bg-masala-red text-white mb-4">For Customers</Badge>
                <h2 className="merriweather text-4xl font-bold text-chai-brown mb-6">
                  Enjoy Fresh, Home-Style Meals Daily
                </h2>
                <p className="text-xl text-chai-brown/80 leading-relaxed mb-8">
                  Experience the convenience of modern technology with the authentic taste of traditional Indian home cooking.
                </p>
              </div>

              <div className="space-y-6">
                {[
                  {
                    icon: <Heart className="w-6 h-6 text-masala-red" />,
                    title: "Meal Preferences",
                    description: "Set dietary preferences, allergies, and favorite dishes for personalized meals"
                  },
                  {
                    icon: <Clock className="w-6 h-6 text-turmeric-yellow" />,
                    title: "Flexible Subscriptions",
                    description: "Daily, weekly, or monthly plans with easy pause and resume options"
                  },
                  {
                    icon: <MapPin className="w-6 h-6 text-curry-green" />,
                    title: "Real-time Tracking",
                    description: "Live GPS tracking of your delivery with accurate arrival times"
                  },
                  {
                    icon: <Star className="w-6 h-6 text-saffron-gold" />,
                    title: "Quality Assurance",
                    description: "Rate meals and provide feedback to maintain the highest quality standards"
                  }
                ].map((feature, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-cream-ivory rounded-lg flex items-center justify-center shadow-md">
                      {feature.icon}
                    </div>
                    <div>
                      <h4 className="font-semibold text-chai-brown mb-2">{feature.title}</h4>
                      <p className="text-chai-brown/70">{feature.description}</p>
                    </div>
                  </div>
                ))}
              </div>

              <Button 
                className="chai-button"
                onClick={() => setShowApp(true)}
              >
                Try Customer App
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Indian Touch Section - Spices & Cultural Elements */}
      <section className="py-20 bg-cream-ivory dabba-pattern">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="merriweather text-4xl font-bold text-chai-brown mb-4">
              Rooted in Indian Tradition
            </h2>
            <p className="text-xl text-chai-brown/70 max-w-3xl mx-auto">
              NourishNet celebrates India's rich culinary heritage while embracing modern technology
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                image: "https://images.unsplash.com/photo-1633881614907-8587c9b93c2f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBzcGljZXMlMjB0dXJtZXJpYyUyMG1hc2FsYXxlbnwxfHx8fDE3NTg5NzQ0Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
                title: "Authentic Spices",
                description: "Traditional masalas and fresh ingredients"
              },
              {
                image: "https://images.unsplash.com/photo-1739242681818-fdee92213ab8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBjaGFpJTIwdGVhJTIwc3RlYW18ZW58MXx8fHwxNzU4OTc0NDM2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
                title: "Fresh Daily",
                description: "Prepared each morning with care and love"
              },
              {
                image: "https://images.unsplash.com/photo-1660987669199-cdee867ab77b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB0aWZmaW4lMjBkYWJiYSUyMGx1bmNoYm94JTIwc3RlZWx8ZW58MXx8fHwxNzU4OTc0NDI0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
                title: "Steel Dabbas",
                description: "Eco-friendly traditional containers"
              },
              {
                image: "https://images.unsplash.com/photo-1559200206-dbfa7a75dd70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdW1iYWklMjBkYWJiYXdhbGElMjBkZWxpdmVyeXxlbnwxfHx8fDE3NTg5NzQ0MjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
                title: "Legacy Service",
                description: "Continuing Mumbai's dabbawala tradition"
              }
            ].map((item, index) => (
              <div key={index} className="text-center group">
                <div className="relative overflow-hidden rounded-2xl mb-4 shadow-lg group-hover:shadow-xl transition-shadow">
                  <ImageWithFallback
                    src={item.image}
                    alt={item.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-chai-brown/30 to-transparent"></div>
                </div>
                <h4 className="merriweather font-bold text-chai-brown mb-2">{item.title}</h4>
                <p className="text-sm text-chai-brown/70">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 bg-chai-brown text-white relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 paisley-pattern opacity-10"></div>
        
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="merriweather text-4xl lg:text-5xl font-bold mb-6">
            Bring Your Dabba Business Online
          </h2>
          <p className="text-xl text-cream-ivory mb-8 max-w-2xl mx-auto">
            Join hundreds of vendors already using NourishNet to digitize their tiffin services. 
            Start your free trial today and experience the future of food delivery.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              className="turmeric-button text-lg px-8 py-4"
              onClick={() => setShowApp(true)}
            >
              <ChefHat className="w-5 h-5 mr-2" />
              Start Free Trial
            </Button>
            <Button className="bg-white text-chai-brown hover:bg-cream-ivory text-lg px-8 py-4">
              <Users className="w-5 h-5 mr-2" />
              Schedule Demo
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-8 border-t border-cream-ivory/20">
            {[
              { number: "500+", label: "Active Vendors" },
              { number: "50K+", label: "Daily Deliveries" },
              { number: "15+", label: "Cities Covered" },
              { number: "4.9★", label: "Customer Rating" }
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-2xl font-bold text-turmeric-yellow mb-1">{stat.number}</div>
                <div className="text-sm text-cream-ivory">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-chai-brown-dark text-cream-ivory py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-spice-gradient rounded-lg flex items-center justify-center">
                  <ChefHat className="w-5 h-5 text-white" />
                </div>
                <span className="merriweather text-lg font-bold">NourishNet</span>
              </div>
              <p className="text-sm text-cream-ivory/80">
                Digitizing India's tiffin services with modern technology and traditional values.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-cream-ivory/80">
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">Vendor Dashboard</a></li>
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">Customer App</a></li>
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">Route Optimization</a></li>
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">Analytics</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-cream-ivory/80">
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">Press</a></li>
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-cream-ivory/80">
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">Documentation</a></li>
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">API Reference</a></li>
                <li><a href="#" className="hover:text-turmeric-yellow transition-colors">Community</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-cream-ivory/20 mt-8 pt-8 text-center text-sm text-cream-ivory/60">
            <p>&copy; 2024 NourishNet. Made with ❤️ for India's food culture.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}