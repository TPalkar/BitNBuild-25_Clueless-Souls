import { useState } from "react";
import { VendorDashboard } from "./vendor/VendorDashboard";
import { ConsumerApp } from "./consumer/ConsumerApp";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Store, Smartphone, ArrowRight, Users, MapPin, CreditCard } from "lucide-react";

type AppMode = "landing" | "vendor" | "consumer";

export function NourishNetApp() {
  const [mode, setMode] = useState<AppMode>("landing");

  if (mode === "vendor") {
    return <VendorDashboard onBack={() => setMode("landing")} />;
  }

  if (mode === "consumer") {
    return <ConsumerApp onBack={() => setMode("landing")} />;
  }

  return (
    <div className="min-h-screen bg-dark-bg">
      {/* Header */}
      <div className="border-b border-dark-border bg-dark-card">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-dark-cta rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">N</span>
              </div>
              <h1 className="text-dark-primary">NourishNet</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => setMode("vendor")}
                className="dark-button-secondary"
              >
                <Store className="w-4 h-4 mr-2" />
                Vendor Login
              </Button>
              <Button
                onClick={() => setMode("consumer")}
                className="dark-button-primary"
              >
                <Smartphone className="w-4 h-4 mr-2" />
                Customer App
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="mb-6">
            Digitize Your Tiffin Service Operations
          </h1>
          <p className="text-xl mb-8 text-dark-secondary">
            Complete SaaS platform for tiffin providers to manage subscriptions, optimize delivery routes, 
            and provide real-time tracking to customers.
          </p>
          
          <div className="flex justify-center space-x-4 mb-16">
            <Button
              onClick={() => setMode("vendor")}
              className="dark-button-primary px-8 py-4"
            >
              <Store className="w-5 h-5 mr-2" />
              Start Managing Your Business
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button
              onClick={() => setMode("consumer")}
              className="dark-button-secondary px-8 py-4"
            >
              <Smartphone className="w-5 h-5 mr-2" />
              Download Customer App
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <Card className="dark-card">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-dark-cta rounded-lg flex items-center justify-center mr-4">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3>Subscriber Management</h3>
            </div>
            <p>
              Comprehensive dashboard to manage all your subscribers, track meal preferences, 
              and handle subscription modifications with ease.
            </p>
          </Card>

          <Card className="dark-card">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-dark-positive rounded-lg flex items-center justify-center mr-4">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <h3>AI Route Optimization</h3>
            </div>
            <p>
              Advanced algorithm calculates the most efficient delivery routes, 
              reducing travel time and fuel costs while ensuring timely deliveries.
            </p>
          </Card>

          <Card className="dark-card">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mr-4">
                <Smartphone className="w-6 h-6 text-white" />
              </div>
              <h3>Real-Time Tracking</h3>
            </div>
            <p>
              Customers can track their delivery in real-time with live location updates, 
              ETA calculations, and delivery milestone notifications.
            </p>
          </Card>

          <Card className="dark-card">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-orange-600 rounded-lg flex items-center justify-center mr-4">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <h3>Flexible Billing</h3>
            </div>
            <p>
              Handle complex subscription models with automated billing cycles, 
              pause/resume functionality, and integrated payment processing.
            </p>
          </Card>

          <Card className="dark-card">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center mr-4">
                <Store className="w-6 h-6 text-white" />
              </div>
              <h3>Menu Management</h3>
            </div>
            <p>
              Create and publish dynamic daily/weekly menus, manage inventory, 
              and update offerings in real-time across all customer touchpoints.
            </p>
          </Card>

          <Card className="dark-card">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mr-4">
                <div className="w-6 h-6 flex items-center justify-center">📊</div>
              </div>
              <h3>Analytics & Insights</h3>
            </div>
            <p>
              Comprehensive business analytics including revenue tracking, customer insights, 
              delivery performance metrics, and growth opportunities.
            </p>
          </Card>
        </div>

        {/* Platform Preview */}
        <div className="text-center">
          <h2 className="mb-8">
            Dual Platform Solution
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div 
              className="cursor-pointer transition-transform hover:scale-105"
              onClick={() => setMode("vendor")}
            >
              <Card className="dark-card p-8">
                <Store className="w-16 h-16 text-dark-cta mx-auto mb-4" />
                <h3 className="mb-4">Vendor Dashboard</h3>
                <p className="mb-6">
                  Web-based admin panel for tiffin providers to manage operations, 
                  track analytics, and optimize delivery processes.
                </p>
                <Button className="dark-button-primary w-full">
                  Explore Vendor Dashboard
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Card>
            </div>

            <div 
              className="cursor-pointer transition-transform hover:scale-105"
              onClick={() => setMode("consumer")}
            >
              <Card className="dark-card p-8">
                <Smartphone className="w-16 h-16 text-dark-cta mx-auto mb-4" />
                <h3 className="mb-4">Consumer Mobile App</h3>
                <p className="mb-6">
                  Modern mobile app for customers to manage subscriptions, 
                  track deliveries, and customize meal preferences.
                </p>
                <Button className="dark-button-primary w-full">
                  View Consumer App
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}