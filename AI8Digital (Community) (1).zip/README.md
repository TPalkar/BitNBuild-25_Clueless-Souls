
  # AI8Digital (Community)

  This is a code bundle for AI8Digital (Community). The original project is available at https://www.figma.com/design/aurisHvXWg7iaeBo9RVYy6/AI8Digital--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  